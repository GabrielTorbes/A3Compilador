
package com.loxcompiler;

import java_cup.runtime.Symbol;
import java.util.List;
import java.util.ArrayList;
import java_cup.runtime.XMLElement;


@SuppressWarnings({"rawtypes"})
public class LoxParser extends java_cup.runtime.lr_parser {

 public final Class getSymbolContainer() {
    return sym.class;
}

  @Deprecated
  public LoxParser() {super();}

  @Deprecated
  public LoxParser(java_cup.runtime.Scanner s) {super(s);}

  public LoxParser(java_cup.runtime.Scanner s, java_cup.runtime.SymbolFactory sf) {super(s,sf);}

  /** Production table. */
  protected static final short _production_table[][] = 
    unpackFromStrings(new String[] {
    "\000\011\000\002\002\004\000\002\002\003\000\002\003" +
    "\004\000\002\003\002\000\002\004\003\000\002\005\003" +
    "\000\002\006\005\000\002\007\003\000\002\007\003" });

  /** Access to production table. */
  public short[][] production_table() {return _production_table;}

  /** Parse-action table. */
  protected static final short[][] _action_table = 
    unpackFromStrings(new String[] {
    "\000\015\000\006\002\ufffe\043\005\001\002\000\004\002" +
    "\017\001\002\000\006\027\013\030\014\001\002\000\006" +
    "\002\ufffd\043\ufffd\001\002\000\006\002\ufffc\043\ufffc\001" +
    "\002\000\004\002\000\001\002\000\006\002\ufffe\043\005" +
    "\001\002\000\004\002\uffff\001\002\000\004\014\ufff9\001" +
    "\002\000\004\014\ufffa\001\002\000\004\014\016\001\002" +
    "\000\006\002\ufffb\043\ufffb\001\002\000\004\002\001\001" +
    "\002" });

  /** Access to parse-action table. */
  public short[][] action_table() {return _action_table;}

  /** <code>reduce_goto</code> table. */
  protected static final short[][] _reduce_table = 
    unpackFromStrings(new String[] {
    "\000\015\000\014\002\003\003\007\004\010\005\005\006" +
    "\006\001\001\000\002\001\001\000\004\007\014\001\001" +
    "\000\002\001\001\000\002\001\001\000\002\001\001\000" +
    "\012\003\011\004\010\005\005\006\006\001\001\000\002" +
    "\001\001\000\002\001\001\000\002\001\001\000\002\001" +
    "\001\000\002\001\001\000\002\001\001" });

  /** Access to <code>reduce_goto</code> table. */
  public short[][] reduce_table() {return _reduce_table;}

  /** Instance of action encapsulation class. */
  protected CUP$LoxParser$actions action_obj;

  /** Action encapsulation object initializer. */
  protected void init_actions()
    {
      action_obj = new CUP$LoxParser$actions(this);
    }

  /** Invoke a user supplied parse action. */
  public java_cup.runtime.Symbol do_action(
    int                        act_num,
    java_cup.runtime.lr_parser parser,
    java.util.Stack            stack,
    int                        top)
    throws java.lang.Exception
  {
    /* call code in generated class */
    return action_obj.CUP$LoxParser$do_action(act_num, parser, stack, top);
  }

  /** Indicates start state. */
  public int start_state() {return 0;}
  /** Indicates start production. */
  public int start_production() {return 0;}

  /** <code>EOF</code> Symbol index. */
  public int EOF_sym() {return 0;}

  /** <code>error</code> Symbol index. */
  public int error_sym() {return 1;}



    private LoxLexer lexer;
    public LoxParser(LoxLexer lexer) {
        super(lexer);
        this.lexer = lexer;
    }


/** Cup generated class to encapsulate user supplied action code.*/
@SuppressWarnings({"rawtypes", "unchecked", "unused"})
class CUP$LoxParser$actions {
  private final LoxParser parser;

  /** Constructor */
  CUP$LoxParser$actions(LoxParser parser) {
    this.parser = parser;
  }

  /** Method 0 with the actual generated action code for actions 0 to 300. */
  public final java_cup.runtime.Symbol CUP$LoxParser$do_action_part00000000(
    int                        CUP$LoxParser$act_num,
    java_cup.runtime.lr_parser CUP$LoxParser$parser,
    java.util.Stack            CUP$LoxParser$stack,
    int                        CUP$LoxParser$top)
    throws java.lang.Exception
    {
      /* Symbol object for return from actions */
      java_cup.runtime.Symbol CUP$LoxParser$result;

      /* select the action based on the action number */
      switch (CUP$LoxParser$act_num)
        {
          /*. . . . . . . . . . . . . . . . . . . .*/
          case 0: // $START ::= program EOF 
            {
              Object RESULT =null;
		int start_valleft = ((java_cup.runtime.Symbol)CUP$LoxParser$stack.elementAt(CUP$LoxParser$top-1)).left;
		int start_valright = ((java_cup.runtime.Symbol)CUP$LoxParser$stack.elementAt(CUP$LoxParser$top-1)).right;
		List<Stmt> start_val = (List<Stmt>)((java_cup.runtime.Symbol) CUP$LoxParser$stack.elementAt(CUP$LoxParser$top-1)).value;
		RESULT = start_val;
              CUP$LoxParser$result = parser.getSymbolFactory().newSymbol("$START",0, ((java_cup.runtime.Symbol)CUP$LoxParser$stack.elementAt(CUP$LoxParser$top-1)), ((java_cup.runtime.Symbol)CUP$LoxParser$stack.peek()), RESULT);
            }
          /* ACCEPT */
          CUP$LoxParser$parser.done_parsing();
          return CUP$LoxParser$result;

          /*. . . . . . . . . . . . . . . . . . . .*/
          case 1: // program ::= declaration_list 
            {
              List<Stmt> RESULT =null;
		int dlleft = ((java_cup.runtime.Symbol)CUP$LoxParser$stack.peek()).left;
		int dlright = ((java_cup.runtime.Symbol)CUP$LoxParser$stack.peek()).right;
		List<Stmt> dl = (List<Stmt>)((java_cup.runtime.Symbol) CUP$LoxParser$stack.peek()).value;
		 RESULT = dl; 
              CUP$LoxParser$result = parser.getSymbolFactory().newSymbol("program",0, ((java_cup.runtime.Symbol)CUP$LoxParser$stack.peek()), ((java_cup.runtime.Symbol)CUP$LoxParser$stack.peek()), RESULT);
            }
          return CUP$LoxParser$result;

          /*. . . . . . . . . . . . . . . . . . . .*/
          case 2: // declaration_list ::= declaration declaration_list 
            {
              List<Stmt> RESULT =null;
		int dleft = ((java_cup.runtime.Symbol)CUP$LoxParser$stack.elementAt(CUP$LoxParser$top-1)).left;
		int dright = ((java_cup.runtime.Symbol)CUP$LoxParser$stack.elementAt(CUP$LoxParser$top-1)).right;
		Stmt d = (Stmt)((java_cup.runtime.Symbol) CUP$LoxParser$stack.elementAt(CUP$LoxParser$top-1)).value;
		int dlleft = ((java_cup.runtime.Symbol)CUP$LoxParser$stack.peek()).left;
		int dlright = ((java_cup.runtime.Symbol)CUP$LoxParser$stack.peek()).right;
		List<Stmt> dl = (List<Stmt>)((java_cup.runtime.Symbol) CUP$LoxParser$stack.peek()).value;
		
        // Pega a lista da recursão (dl), adiciona a nova declaração (d) no início,
        // e define a lista atualizada como o resultado.
        dl.add(0, d);
        RESULT = dl;
    
              CUP$LoxParser$result = parser.getSymbolFactory().newSymbol("declaration_list",1, ((java_cup.runtime.Symbol)CUP$LoxParser$stack.elementAt(CUP$LoxParser$top-1)), ((java_cup.runtime.Symbol)CUP$LoxParser$stack.peek()), RESULT);
            }
          return CUP$LoxParser$result;

          /*. . . . . . . . . . . . . . . . . . . .*/
          case 3: // declaration_list ::= 
            {
              List<Stmt> RESULT =null;
		
        // O resultado de uma lista vazia é um novo ArrayList.
        RESULT = new ArrayList<Stmt>();
    
              CUP$LoxParser$result = parser.getSymbolFactory().newSymbol("declaration_list",1, ((java_cup.runtime.Symbol)CUP$LoxParser$stack.peek()), RESULT);
            }
          return CUP$LoxParser$result;

          /*. . . . . . . . . . . . . . . . . . . .*/
          case 4: // declaration ::= statement 
            {
              Stmt RESULT =null;
		int sleft = ((java_cup.runtime.Symbol)CUP$LoxParser$stack.peek()).left;
		int sright = ((java_cup.runtime.Symbol)CUP$LoxParser$stack.peek()).right;
		Stmt s = (Stmt)((java_cup.runtime.Symbol) CUP$LoxParser$stack.peek()).value;
		 RESULT = s; 
              CUP$LoxParser$result = parser.getSymbolFactory().newSymbol("declaration",2, ((java_cup.runtime.Symbol)CUP$LoxParser$stack.peek()), ((java_cup.runtime.Symbol)CUP$LoxParser$stack.peek()), RESULT);
            }
          return CUP$LoxParser$result;

          /*. . . . . . . . . . . . . . . . . . . .*/
          case 5: // statement ::= print_statement 
            {
              Stmt RESULT =null;
		int psleft = ((java_cup.runtime.Symbol)CUP$LoxParser$stack.peek()).left;
		int psright = ((java_cup.runtime.Symbol)CUP$LoxParser$stack.peek()).right;
		Stmt.Print ps = (Stmt.Print)((java_cup.runtime.Symbol) CUP$LoxParser$stack.peek()).value;
		 RESULT = ps; 
              CUP$LoxParser$result = parser.getSymbolFactory().newSymbol("statement",3, ((java_cup.runtime.Symbol)CUP$LoxParser$stack.peek()), ((java_cup.runtime.Symbol)CUP$LoxParser$stack.peek()), RESULT);
            }
          return CUP$LoxParser$result;

          /*. . . . . . . . . . . . . . . . . . . .*/
          case 6: // print_statement ::= PRINT expression SEMICOLON 
            {
              Stmt.Print RESULT =null;
		int eleft = ((java_cup.runtime.Symbol)CUP$LoxParser$stack.elementAt(CUP$LoxParser$top-1)).left;
		int eright = ((java_cup.runtime.Symbol)CUP$LoxParser$stack.elementAt(CUP$LoxParser$top-1)).right;
		Expr e = (Expr)((java_cup.runtime.Symbol) CUP$LoxParser$stack.elementAt(CUP$LoxParser$top-1)).value;
		
        // Cria um novo nó Stmt.Print, passando o resultado da regra 'expression' (e)
        // como seu filho na árvore.
        RESULT = new Stmt.Print(e);
    
              CUP$LoxParser$result = parser.getSymbolFactory().newSymbol("print_statement",4, ((java_cup.runtime.Symbol)CUP$LoxParser$stack.elementAt(CUP$LoxParser$top-2)), ((java_cup.runtime.Symbol)CUP$LoxParser$stack.peek()), RESULT);
            }
          return CUP$LoxParser$result;

          /*. . . . . . . . . . . . . . . . . . . .*/
          case 7: // expression ::= NUMBER 
            {
              Expr RESULT =null;
		int nleft = ((java_cup.runtime.Symbol)CUP$LoxParser$stack.peek()).left;
		int nright = ((java_cup.runtime.Symbol)CUP$LoxParser$stack.peek()).right;
		Double n = (Double)((java_cup.runtime.Symbol) CUP$LoxParser$stack.peek()).value;
		
        // Cria um novo nó Expr.Literal, guardando o valor do token NUMBER (n).
        RESULT = new Expr.Literal(n);
    
              CUP$LoxParser$result = parser.getSymbolFactory().newSymbol("expression",5, ((java_cup.runtime.Symbol)CUP$LoxParser$stack.peek()), ((java_cup.runtime.Symbol)CUP$LoxParser$stack.peek()), RESULT);
            }
          return CUP$LoxParser$result;

          /*. . . . . . . . . . . . . . . . . . . .*/
          case 8: // expression ::= STRING 
            {
              Expr RESULT =null;
		int sleft = ((java_cup.runtime.Symbol)CUP$LoxParser$stack.peek()).left;
		int sright = ((java_cup.runtime.Symbol)CUP$LoxParser$stack.peek()).right;
		String s = (String)((java_cup.runtime.Symbol) CUP$LoxParser$stack.peek()).value;
		
        // Cria um novo nó Expr.Literal, guardando o valor do token STRING (s).
        RESULT = new Expr.Literal(s);
    
              CUP$LoxParser$result = parser.getSymbolFactory().newSymbol("expression",5, ((java_cup.runtime.Symbol)CUP$LoxParser$stack.peek()), ((java_cup.runtime.Symbol)CUP$LoxParser$stack.peek()), RESULT);
            }
          return CUP$LoxParser$result;

          /* . . . . . .*/
          default:
            throw new Exception(
               "Invalid action number "+CUP$LoxParser$act_num+"found in internal parse table");

        }
    } /* end of method */

  /** Method splitting the generated action code into several parts. */
  public final java_cup.runtime.Symbol CUP$LoxParser$do_action(
    int                        CUP$LoxParser$act_num,
    java_cup.runtime.lr_parser CUP$LoxParser$parser,
    java.util.Stack            CUP$LoxParser$stack,
    int                        CUP$LoxParser$top)
    throws java.lang.Exception
    {
              return CUP$LoxParser$do_action_part00000000(
                               CUP$LoxParser$act_num,
                               CUP$LoxParser$parser,
                               CUP$LoxParser$stack,
                               CUP$LoxParser$top);
    }
}

}
