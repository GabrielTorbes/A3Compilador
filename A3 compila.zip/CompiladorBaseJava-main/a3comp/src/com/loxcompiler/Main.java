package com.loxcompiler;

import java.io.StringReader;
import java.util.List;

public class Main {
    public static void main(String[] args) throws Exception {
        String sourceCode = "print \"Olá, mundo!\"; print 123;";

        // 1. Inicializa o Lexer
        LoxLexer lexer = new LoxLexer(new StringReader(sourceCode));

        // 2. Inicializa o Parser com o Lexer
        LoxParser parser = new LoxParser(lexer);

        // 3. Roda o Parser. O resultado é um Object, fazemos o cast para List<Stmt>
        List<Stmt> statements = (List<Stmt>) parser.parse().value;

        // 4. Se chegou até aqui, o parsing foi!!!!!!!!!!!!
        System.out.println("Análise Sintática concluída. AST gerada:");

        // 5. Usa o AstPrinter para visualizar a árvore
        AstPrinter printer = new AstPrinter();
        String astRepresentation = printer.print(statements);
        System.out.println(astRepresentation);
    }
}